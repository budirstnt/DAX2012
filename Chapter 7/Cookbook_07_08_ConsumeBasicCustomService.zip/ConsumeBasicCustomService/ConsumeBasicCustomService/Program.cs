﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ConsumeBasicCustomService.CustomCurrencyServices;

namespace ConsumeBasicCustomService
{
    class Program
    {
        static void Main(string[] args)
        {
            CustomCurrencyServiceClient serviceClient =
                new CustomCurrencyServiceClient();
            string currencyName = serviceClient.getCurrencyName(null, "EUR");
            Console.WriteLine(currencyName);
            Console.ReadLine();
        }
    }
}
