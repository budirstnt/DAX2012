﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ConsumeSystemQueryService.QueryService;
using System.Data;

namespace ConsumeSystemQueryService
{
    class Program
    {
        static void Main(string[] args)
        {
            QueryServiceClient serviceClient;
            QueryMetadata query;
            QueryDataSourceMetadata currencyDataSource;
            QueryDataFieldMetadata field1, field2;
            Paging paging = null;
            DataSet result;

            query = new QueryMetadata();
            query.QueryType = QueryService.QueryType.Join;
            query.AllowCrossCompany = true;
            query.DataSources = new QueryDataSourceMetadata[1];

            currencyDataSource = new QueryDataSourceMetadata();
            currencyDataSource.Name = "Currency";
            currencyDataSource.Enabled = true;
            currencyDataSource.FetchMode = FetchMode.OneToOne;
            currencyDataSource.Table = "Currency";
            currencyDataSource.DynamicFieldList = false;
            currencyDataSource.Fields = new QueryFieldMetadata[2];
            query.DataSources[0] = currencyDataSource;

            field1 = new QueryDataFieldMetadata();
            field1.FieldName = "CurrencyCode";
            field1.SelectionField = SelectionField.Database;
            currencyDataSource.Fields[0] = field1;

            field2 = new QueryDataFieldMetadata();
            field2.FieldName = "Txt";
            field2.SelectionField = SelectionField.Database;
            currencyDataSource.Fields[1] = field2;

            serviceClient = new QueryServiceClient();
            result = serviceClient.ExecuteQuery(query, ref paging);

            foreach (DataRow row in result.Tables[0].Rows)
            {
                Console.WriteLine(String.Format("{0} - {1}", row[0], row[1]));
            }

            Console.ReadLine();
        }
    }
}
