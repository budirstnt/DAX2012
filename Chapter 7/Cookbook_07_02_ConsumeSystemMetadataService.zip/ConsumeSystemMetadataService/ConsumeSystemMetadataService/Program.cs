﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ConsumeSystemMetadataService.MetadataService;

namespace ConsumeSystemMetadataService
{
    class Program
    {
        static void Main(string[] args)
        {
            AxMetadataServiceClient serviceClient;
            TableMetadata[] tables;

            serviceClient = new AxMetadataServiceClient();
            serviceClient.Open();

            tables = serviceClient.GetTableMetadataByName(
                new string[] { "Currency", "ExchangeRate" });

            for (int i = 0; i < tables.Length; i++)
            {
                Console.WriteLine(
                    String.Format("{0}: {1}, {2}",
                    tables[i].Name,
                    tables[i].TitleField1.Name,
                    tables[i].TitleField2.Name));
            }

            Console.ReadLine();

            serviceClient.Close();
        }
    }
}
