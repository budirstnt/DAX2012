﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ConsumeExistingDocumentService.CurrencyServices;

namespace ConsumeExistingDocumentService
{
    class Program
    {
        static void Main(string[] args)
        {
            CurrencyServiceClient serviceClient;
            AxdLedgerCurrency currency;

            KeyField keyField = new KeyField();
            keyField.Field = "CurrencyCode";
            keyField.Value = "LTL";

            EntityKey keys = new EntityKey();
            keys.KeyData = new KeyField[1] { keyField };

            serviceClient = new CurrencyServiceClient();
            currency = serviceClient.read(null, new EntityKey[1] { keys });

            Console.WriteLine(
                String.Format("{0} - {1}",
                currency.Currency[0].CurrencyCode,
                currency.Currency[0].Txt));

            Console.ReadLine();
        }
    }
}
