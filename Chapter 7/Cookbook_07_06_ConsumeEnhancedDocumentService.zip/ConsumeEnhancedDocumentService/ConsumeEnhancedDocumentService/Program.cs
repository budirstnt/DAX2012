﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ConsumeEnhancedDocumentService.EnhancedCurrencyServices;

namespace ConsumeEnhancedDocumentService
{
    class Program
    {
        static void Main(string[] args)
        {
            CurrencyQueryServiceClient serviceClient =
                new CurrencyQueryServiceClient();
            EntityKeyPage keyPage = serviceClient.getKeys(null, null);

            for (int i = 0; i < keyPage.EntityKeyList.Length; i++)
            {
                Console.WriteLine(keyPage.EntityKeyList[i].KeyData[0].Value);
            }

            Console.ReadLine();
        }
    }
}
