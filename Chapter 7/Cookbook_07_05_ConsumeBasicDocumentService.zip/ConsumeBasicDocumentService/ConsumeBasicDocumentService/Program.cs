﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ConsumeBasicDocumentService.BasicCurrencyServices;

namespace ConsumeBasicDocumentService
{
    class Program
    {
        static void Main(string[] args)
        {
            CriteriaElement criteriaElement = new CriteriaElement();
            criteriaElement.DataSourceName = "Currency";
            criteriaElement.FieldName = "CurrencyCode";
            criteriaElement.Value1 = "";
            criteriaElement.Operator = Operator.NotEqual;

            QueryCriteria query = new QueryCriteria();
            query.CriteriaElement = new CriteriaElement[1] { criteriaElement };

            CurrencyQueryServiceClient serviceClient = new CurrencyQueryServiceClient();
            AxdCurrencyQuery currency = serviceClient.find(null, query);

            if (currency.Currency != null)
            {
                for (int i = 0; i < currency.Currency.Length; i++)
                {
                    Console.WriteLine(
                        String.Format("{0} - {1}",
                        currency.Currency[i].CurrencyCode,
                        currency.Currency[i].Txt));
                }
            }

            Console.ReadLine();
        }
    }
}
