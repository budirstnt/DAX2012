﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ExtSrv
{
    public class Class1
    {
    }
}
